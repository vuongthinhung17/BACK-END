﻿
using lab2.Models;
using Microsoft.AspNetCore.Mvc;

namespace lab2.Controllers
{
    public class ToDoController1 : Controller
    {
     

        public IActionResult Index()
        {
            return View();
        }

        // GET: Add
        public IActionResult Add()
        {
            return View();
        }

        // POST: Add
        [HttpPost]
 

        // GET: Edit
        public IActionResult Edit()
        {
            return View();
        }

        // POST: Delete (tạm placeholder)
        [HttpPost]
        public IActionResult Delete()
        {
            return View();
        }
    }
}
    



