﻿
namespace lab2.Controllers
{
    internal class Todo
    {
        internal static object FirstOrDefault(Func<object, bool> value)
        {
            throw new NotImplementedException();
        }

        internal static void Remove(object todo)
        {
            throw new NotImplementedException();
        }
    }
}