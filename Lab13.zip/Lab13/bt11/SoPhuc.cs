﻿using System;

namespace bt11
{
     public class SoPhuc
    {
        public double phanThuc;
        public double phanAo;

        // Hàm tạo không đối số
        public SoPhuc()
        {
            phanThuc = 0;
            phanAo = 0;
        }

        // Hàm tạo có đối số
        public SoPhuc(double a, double b)
        {
            phanThuc = a;
            phanAo = b;
        }

        // Nhập số phức
        public void Nhap()
        {
            Console.Write("Nhập phần thực: ");
            phanThuc = double.Parse(Console.ReadLine());
            Console.Write("Nhập phần ảo: ");
            phanAo = double.Parse(Console.ReadLine());
        }

        // Hiển thị số phức
        public void HienThi()
        {
            Console.WriteLine($"{phanThuc} {(phanAo >= 0 ? "+" : "-")} {Math.Abs(phanAo)}i");
        }

        // Cộng 2 số phức
        public SoPhuc Cong(SoPhuc b)
        {
            return new SoPhuc(phanThuc + b.phanThuc, phanAo + b.phanAo);
        }

        // Trừ 2 số phức
        public SoPhuc Tru(SoPhuc b)
        {
            return new SoPhuc(phanThuc - b.phanThuc, phanAo - b.phanAo);
        }

        // Nhân 2 số phức
        public SoPhuc Nhan(SoPhuc b)
        {
            double thuc = phanThuc * b.phanThuc - phanAo * b.phanAo;
            double ao = phanThuc * b.phanAo + phanAo * b.phanThuc;
            return new SoPhuc(thuc, ao);
        }

        // Chia 2 số phức
        public SoPhuc Chia(SoPhuc b)
        {
            double mau = b.phanThuc * b.phanThuc + b.phanAo * b.phanAo;
            if (mau == 0)
                throw new DivideByZeroException("Không thể chia cho số phức có cả phần thực và phần ảo bằng 0.");

            double thuc = (phanThuc * b.phanThuc + phanAo * b.phanAo) / mau;
            double ao = (phanAo * b.phanThuc - phanThuc * b.phanAo) / mau;
            return new SoPhuc(thuc, ao);
        }
    }

}
