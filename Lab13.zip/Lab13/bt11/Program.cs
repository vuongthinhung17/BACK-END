﻿using System;
using System.Text;
using bt11;

class Program
{
    static void Main()
    {
        // Sửa lỗi hiển thị tiếng Việt trên Console
        Console.OutputEncoding = Encoding.UTF8;

        Console.WriteLine("Nhập số phức A:");
        SoPhuc A = new SoPhuc();
        A.Nhap();

        Console.WriteLine("Nhập số phức B:");
        SoPhuc B = new SoPhuc();
        B.Nhap();

        int luaChon;
        do
        {
            Console.WriteLine("\n===== MENU =====");
            Console.WriteLine("1. Tính tổng hai số phức");
            Console.WriteLine("2. Tính hiệu hai số phức");
            Console.WriteLine("3. Tính tích hai số phức");
            Console.WriteLine("4. Tính thương hai số phức");
            Console.WriteLine("5. Thoát");
            Console.Write("Nhập lựa chọn của bạn: ");
            luaChon = int.Parse(Console.ReadLine());

            SoPhuc ketQua;
            try
            {
                switch (luaChon)
                {
                    case 1:
                        ketQua = A.Cong(B);
                        Console.Write("Tổng: ");
                        ketQua.HienThi();
                        break;
                    case 2:
                        ketQua = A.Tru(B);
                        Console.Write("Hiệu: ");
                        ketQua.HienThi();
                        break;
                    case 3:
                        ketQua = A.Nhan(B);
                        Console.Write("Tích: ");
                        ketQua.HienThi();
                        break;
                    case 4:
                        ketQua = A.Chia(B);
                        Console.Write("Thương: ");
                        ketQua.HienThi();
                        break;
                    case 5:
                        Console.WriteLine("Kết thúc chương trình.");
                        break;
                    default:
                        Console.WriteLine("Lựa chọn không hợp lệ.");
                        break;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Lỗi: " + ex.Message);
            }

        } while (luaChon != 5);
    }
}
