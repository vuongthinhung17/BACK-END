﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bt3
{
    abstract class ThiSinh
    {
        private int ut;

        public string SBD {  get; set; }    
        public string HoTen { get; set; } 
        public string DiaChi { get; set; }
        public  int UuTien { get; set; }
        public abstract double TongDiem();
        public virtual void Nhap()
        {
            Console.WriteLine("Số báo danh: ");
            SBD = Console.ReadLine();
            Console.WriteLine("Họ tên: ");
            HoTen = Console.ReadLine();
            Console.WriteLine("Địa chỉ: ");
            DiaChi = Console.ReadLine();
            Console.WriteLine("Điểm ưu tiên");
            while (!int.TryParse(Console.ReadLine(),out int ut)|| ut < 0);
            Console.WriteLine("Nhập lại: ");
            UuTien = ut;
        }
        public virtual void Xuat()
        {
            Console.WriteLine($"SBD: {SBD}, Họ tên: {HoTen}, Địa chỉ: {DiaChi}, Ưu tiên: {UuTien}, Tổng điểm: {TongDiem()}");
        }
        class ThiSinhKhoiA : ThiSinh
        {
            private double Toan, Ly, Hoa;

            public override void Nhap()
            {
                base.Nhap();
                Console.Write("Điểm Toán: "); Toan = double.Parse(Console.ReadLine());
                Console.Write("Điểm Lý: "); Ly = double.Parse(Console.ReadLine());
                Console.Write("Điểm Hóa: "); Hoa = double.Parse(Console.ReadLine());
            }

            public override double TongDiem() => Toan + Ly + Hoa + UuTien;
        }

        class ThiSinhKhoiB : ThiSinh
        {
            private double Toan, Hoa, Sinh;

            public override void Nhap()
            {
                base.Nhap();
                Console.Write("Điểm Toán: "); Toan = double.Parse(Console.ReadLine());
                Console.Write("Điểm Hóa: "); Hoa = double.Parse(Console.ReadLine());
                Console.Write("Điểm Sinh: "); Sinh = double.Parse(Console.ReadLine());
            }

            public override double TongDiem() => Toan + Hoa + Sinh + UuTien;
        }

        class ThiSinhKhoiC : ThiSinh
        {
            private double Van, Su, Dia;

            public override void Nhap()
            {
                base.Nhap();
                Console.Write("Điểm Văn: "); Van = double.Parse(Console.ReadLine());
                Console.Write("Điểm Sử: "); Su = double.Parse(Console.ReadLine());
                Console.Write("Điểm Địa: "); Dia = double.Parse(Console.ReadLine());
            }

            public override double TongDiem() => Van + Su + Dia + UuTien;
        }

        class TuyenSinh
        {
            private List<ThiSinh> danhSach = new List<ThiSinh>();

            public void NhapThiSinh()
            {
                Console.WriteLine("Chọn khối thi (A/B/C): ");
                string khoi = Console.ReadLine()?.ToUpper();

                ThiSinh ts = null;
                switch (khoi)
                {
                    case "A": ts = new ThiSinhKhoiA(); break;
                    case "B": ts = new ThiSinhKhoiB(); break;
                    case "C": ts = new ThiSinhKhoiC(); break;
                    default:
                        Console.WriteLine("Khối không hợp lệ.");
                        return;
                }

                ts.Nhap();
                danhSach.Add(ts);
            }

            public void HienThiTrungTuyen()
            {
                Console.WriteLine("=== DANH SÁCH TRÚNG TUYỂN ===");
                foreach (var ts in danhSach)
                {
                    double tong = ts.TongDiem();
                    bool trungTuyen = (ts is ThiSinhKhoiA && tong >= 15) ||
                                      (ts is ThiSinhKhoiB && tong >= 16) ||
                                      (ts is ThiSinhKhoiC && tong >= 13.5);

                    if (trungTuyen)
                        ts.Xuat();
                }
            }

            public void TimTheoSBD(string sbd)
            {
                foreach (var ts in danhSach)
                {
                    if (ts.SBD.Equals(sbd, StringComparison.OrdinalIgnoreCase))
                    {
                        ts.Xuat();
                        return;
                    }
                }
                Console.WriteLine("Không tìm thấy thí sinh có SBD: " + sbd);
            }
        }

    }
}
