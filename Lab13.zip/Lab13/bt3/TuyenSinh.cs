﻿
internal class TuyenSinh
{
    internal void HienThiTrungTuyen()
    {
        throw new NotImplementedException();
    }

    internal void NhapThiSinh()
    {
        throw new NotImplementedException();
    }

    internal void TimTheoSBD(string? sbd)
    {
        throw new NotImplementedException();
    }
}