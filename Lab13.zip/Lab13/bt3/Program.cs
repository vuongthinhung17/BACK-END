﻿using System.Text;

class Program
{
    static void Main()
    {
        Console.OutputEncoding = Encoding.UTF8;
        TuyenSinh ts = new TuyenSinh();

        while (true)
        {
            Console.WriteLine("\n==== MENU ====");
            Console.WriteLine("1. Nhập thí sinh");
            Console.WriteLine("2. Hiển thị thí sinh trúng tuyển");
            Console.WriteLine("3. Tìm theo số báo danh");
            Console.WriteLine("4. Thoát");
            Console.Write("Chọn: ");
            string chon = Console.ReadLine();

            switch (chon)
            {
                case "1":
                    ts.NhapThiSinh();
                    break;
                case "2":
                    ts.HienThiTrungTuyen();
                    break;
                case "3":
                    Console.Write("Nhập SBD cần tìm: ");
                    string sbd = Console.ReadLine();
                    ts.TimTheoSBD(sbd);
                    break;
                case "4":
                    return;
                default:
                    Console.WriteLine("Chọn sai! Vui lòng chọn lại.");
                    break;
            }
        }
    }
}
