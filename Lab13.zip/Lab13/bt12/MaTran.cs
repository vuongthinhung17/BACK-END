﻿using System;
using System.Text;


namespace bt12
{
      public class MaTran
    {
        public int SoDong, SoCot;
        public double[,] DuLieu;

        // Hàm tạo không đối số
        public MaTran()
        {
            SoDong = 0;
            SoCot = 0;
            DuLieu = new double[0, 0];
        }

        // Hàm tạo có đối số
        public MaTran(int dong, int cot)
        {
            SoDong = dong;
            SoCot = cot;
            DuLieu = new double[dong, cot];
        }

        // Nhập ma trận
        public void Nhap()
        {
            Console.WriteLine($"Nhập ma trận {SoDong}x{SoCot}:");
            for (int i = 0; i < SoDong; i++)
            {
                for (int j = 0; j < SoCot; j++)
                {
                    Console.Write($"Nhập phần tử [{i + 1},{j + 1}]: ");
                    DuLieu[i, j] = double.Parse(Console.ReadLine());
                }
            }
        }

        // Hiển thị ma trận
        public void HienThi()
        {
            for (int i = 0; i < SoDong; i++)
            {
                for (int j = 0; j < SoCot; j++)
                {
                    Console.Write(DuLieu[i, j] + "\t");
                }
                Console.WriteLine();
            }
        }

        // Cộng hai ma trận
        public MaTran Cong(MaTran b)
        {
            if (SoDong != b.SoDong || SoCot != b.SoCot)
                throw new Exception("Hai ma trận không cùng cấp!");

            MaTran kq = new MaTran(SoDong, SoCot);
            for (int i = 0; i < SoDong; i++)
                for (int j = 0; j < SoCot; j++)
                    kq.DuLieu[i, j] = DuLieu[i, j] + b.DuLieu[i, j];

            return kq;
        }

        // Hiệu hai ma trận
        public MaTran Tru(MaTran b)
        {
            if (SoDong != b.SoDong || SoCot != b.SoCot)
                throw new Exception("Hai ma trận không cùng cấp!");

            MaTran kq = new MaTran(SoDong, SoCot);
            for (int i = 0; i < SoDong; i++)
                for (int j = 0; j < SoCot; j++)
                    kq.DuLieu[i, j] = DuLieu[i, j] - b.DuLieu[i, j];

            return kq;
        }

        // Nhân hai ma trận
        public MaTran Nhan(MaTran b)
        {
            if (SoCot != b.SoDong)
                throw new Exception("Số cột của ma trận A phải bằng số dòng của ma trận B");

            MaTran kq = new MaTran(SoDong, b.SoCot);
            for (int i = 0; i < SoDong; i++)
                for (int j = 0; j < b.SoCot; j++)
                    for (int k = 0; k < SoCot; k++)
                        kq.DuLieu[i, j] += DuLieu[i, k] * b.DuLieu[k, j];

            return kq;
        }

        // Thương ma trận (nếu yêu cầu, có thể chia từng phần tử tương ứng)
        public MaTran Thuong(MaTran b)
        {
            if (SoDong != b.SoDong || SoCot != b.SoCot)
                throw new Exception("Hai ma trận không cùng cấp!");

            MaTran kq = new MaTran(SoDong, SoCot);
            for (int i = 0; i < SoDong; i++)
                for (int j = 0; j < SoCot; j++)
                {
                    if (b.DuLieu[i, j] == 0)
                        throw new DivideByZeroException($"Phần tử tại [{i},{j}] là 0, không thể chia.");
                    kq.DuLieu[i, j] = DuLieu[i, j] / b.DuLieu[i, j];
                }

            return kq;
        }
    }

}