﻿using System;
using System.Text;
using bt12;

class Program
{
    static void Main()
    {
        Console.OutputEncoding = Encoding.UTF8;

        Console.Write("Nhập số dòng: ");
        int dong = int.Parse(Console.ReadLine());
        Console.Write("Nhập số cột: ");
        int cot = int.Parse(Console.ReadLine());

        MaTran A = new MaTran(dong, cot);
        Console.WriteLine("Nhập ma trận A:");
        A.Nhap();

        MaTran B = new MaTran(dong, cot);
        Console.WriteLine("Nhập ma trận B:");
        B.Nhap();

        int chon;
        do
        {
            Console.WriteLine("\n==== MENU ====");
            Console.WriteLine("1. Tính tổng hai ma trận");
            Console.WriteLine("2. Tính hiệu hai ma trận");
            Console.WriteLine("3. Tính tích hai ma trận");
            Console.WriteLine("4. Tính thương hai ma trận (chia phần tử)");
            Console.WriteLine("5. Thoát");
            Console.Write("Chọn thao tác: ");
            chon = int.Parse(Console.ReadLine());

            try
            {
                MaTran kq;
                switch (chon)
                {
                    case 1:
                        kq = A.Cong(B);
                        Console.WriteLine("Tổng A + B là:");
                        kq.HienThi();
                        break;
                    case 2:
                        kq = A.Tru(B);
                        Console.WriteLine("Hiệu A - B là:");
                        kq.HienThi();
                        break;
                    case 3:
                        kq = A.Nhan(B);
                        Console.WriteLine("Tích A * B là:");
                        kq.HienThi();
                        break;
                    case 4:
                        kq = A.Thuong(B);
                        Console.WriteLine("Thương A / B là:");
                        kq.HienThi();
                        break;
                    case 5:
                        Console.WriteLine("Kết thúc chương trình.");
                        break;
                    default:
                        Console.WriteLine("Lựa chọn không hợp lệ.");
                        break;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Lỗi: " + ex.Message);
            }

        } while (chon != 5);
    }
}
