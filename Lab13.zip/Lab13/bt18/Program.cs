﻿using System;
using System.Collections.Generic;
using System.Text;
using bt18;

class Program
{
    static void Main()
    {
        Console.OutputEncoding = Encoding.UTF8;

        List<CoQuan> danhSach = new List<CoQuan>();

        while (true)
        {
            Console.WriteLine("\nMenu:");
            Console.WriteLine("1. Nhập thông tin cá nhân");
            Console.WriteLine("2. Hiển thị cá nhân thuộc đơn vị 'Phòng tài chính'");
            Console.WriteLine("3. Tìm kiếm thông tin theo họ tên");
            Console.WriteLine("4. Thoát");
            Console.Write("Chọn chức năng (1-4): ");
            string choice = Console.ReadLine();

            switch (choice)
            {
                case "1":
                    NhapDanhSach(danhSach);
                    break;
                case "2":
                    HienThiPhongTaiChinh(danhSach);
                    break;
                case "3":
                    TimKiemTheoHoTen(danhSach);
                    break;
                case "4":
                    Console.WriteLine("Thoát chương trình.");
                    return;
                default:
                    Console.WriteLine("Chọn sai, vui lòng chọn lại.");
                    break;
            }
        }
    }

    static void NhapDanhSach(List<CoQuan> ds)
    {
        Console.Write("Nhập số lượng cá nhân: ");
        int n = int.Parse(Console.ReadLine());

        for (int i = 0; i < n; i++)
        {
            Console.WriteLine($"Nhập thông tin cá nhân thứ {i + 1}:");

            Console.Write("Họ tên: ");
            string hoTen = Console.ReadLine();

            Console.Write("Giới tính (Nam/Nữ): ");
            string gt = Console.ReadLine().Trim().ToLower();
            bool gioiTinh = (gt == "nam");

            Console.Write("Tuổi: ");
            int tuoi = int.Parse(Console.ReadLine());

            Console.Write("Đơn vị công tác: ");
            string donVi = Console.ReadLine();

            Console.Write("Hệ số lương: ");
            double heSoLuong = double.Parse(Console.ReadLine());

            ds.Add(new CoQuan(hoTen, gioiTinh, tuoi, donVi, heSoLuong));
        }
    }

    static void HienThiPhongTaiChinh(List<CoQuan> ds)
    {
        Console.WriteLine("\nDanh sách cá nhân thuộc 'Phòng tài chính':");
        bool found = false;
        foreach (var nq in ds)
        {
            if (nq.DonViCongTac.Equals("Phòng tài chính", StringComparison.OrdinalIgnoreCase))
            {
                nq.In();
                Console.WriteLine("------------------------");
                found = true;
            }
        }
        if (!found)
            Console.WriteLine("Không tìm thấy cá nhân nào thuộc 'Phòng tài chính'.");
    }

    static void TimKiemTheoHoTen(List<CoQuan> ds)
    {
        Console.Write("Nhập họ tên cần tìm: ");
        string tenTim = Console.ReadLine();

        bool found = false;
        foreach (var nq in ds)
        {
            if (nq.HoTen.IndexOf(tenTim, StringComparison.OrdinalIgnoreCase) >= 0)
            {
                nq.In();
                Console.WriteLine("------------------------");
                found = true;
            }
        }
        if (!found)
            Console.WriteLine("Không tìm thấy cá nhân với họ tên này.");
    }
}
