﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bt18
{
    using System;

    public class CoQuan : Nguoi
    {
        public string DonViCongTac { get; set; }
        public double HeSoLuong { get; set; }

        // Lương cơ bản hiện tại
        public const double LuongCoBan = 1050000;

        public CoQuan() : base()
        {
            DonViCongTac = "";
            HeSoLuong = 0;
        }

        public CoQuan(string hoTen, bool gioiTinh, int tuoi, string donVi, double heSoLuong)
            : base(hoTen, gioiTinh, tuoi)
        {
            DonViCongTac = donVi;
            HeSoLuong = heSoLuong;
        }

        public override void In()
        {
            base.In();
            Console.WriteLine($"Đơn vị công tác: {DonViCongTac}");
            Console.WriteLine($"Hệ số lương: {HeSoLuong}");
            Console.WriteLine($"Lương: {TinhLuong():N0} VND");
        }

        public double TinhLuong()
        {
            return HeSoLuong * LuongCoBan;
        }
    }

}
