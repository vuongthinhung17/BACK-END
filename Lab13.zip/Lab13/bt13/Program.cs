﻿using System;
using bt13;

namespace Bai13
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = System.Text.Encoding.UTF8;
            QLPTGT ql = new QLPTGT();
            while (true)
            {
                Console.WriteLine("\n----- MENU -----");
                Console.WriteLine("1. Nhập đăng ký phương tiện");
                Console.WriteLine("2. Tìm kiếm phương tiện");
                Console.WriteLine("3. Hiển thị tất cả phương tiện");
                Console.WriteLine("0. Thoát");
                Console.Write("Chọn: ");
                int chon = int.Parse(Console.ReadLine());

                switch (chon)
                {
                    case 1: ql.Nhap(); break;
                    case 2: ql.TimKiem(); break;
                    case 3: ql.HienThiTatCa(); break;
                    case 0: return;
                    default: Console.WriteLine("Lựa chọn không hợp lệ!"); break;
                }
            }
        }
    }
}
