﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bt13
{
    internal class QLPTGT
    {
        private List<PTGT> dsPTGT = new List<PTGT>();

        public void Nhap()
        {
            Console.Write("Nhập số lượng phương tiện: ");
            int n = int.Parse(Console.ReadLine());
            for (int i = 0; i < n; i++)
            {
                Console.WriteLine($"-- Nhập phương tiện thứ {i + 1} --");
                Console.WriteLine("1. Ô tô\n2. Xe máy\n3. Xe tải");
                int chon = int.Parse(Console.ReadLine());
                PTGT pt;
                switch (chon)
                {
                    case 1: pt = new OTo(); break;
                    case 2: pt = new XeMay(); break;
                    case 3: pt = new XeTai(); break;
                    default: Console.WriteLine("Lựa chọn không hợp lệ!"); continue;
                }
                pt.Nhap();
                dsPTGT.Add(pt);
            }
        }

        public void TimKiem()
        {
            Console.WriteLine("1. Tìm theo màu\n2. Tìm theo năm sản xuất");
            int chon = int.Parse(Console.ReadLine());
            if (chon == 1)
            {
                Console.Write("Nhập màu: ");
                string mau = Console.ReadLine();
                foreach (var pt in dsPTGT)
                {
                    if (pt.Mau.ToLower() == mau.ToLower()) pt.Xuat();
                }
            }
            else if (chon == 2)
            {
                Console.Write("Nhập năm sản xuất: ");
                int nam = int.Parse(Console.ReadLine());
                foreach (var pt in dsPTGT)
                {
                    if (pt.NamSanXuat == nam) pt.Xuat();
                }
            }
            else
            {
                Console.WriteLine("Lựa chọn không hợp lệ!");
            }
        }

        public void HienThiTatCa()
        {
            foreach (var pt in dsPTGT)
            {
                pt.Xuat();
                Console.WriteLine("---------------------------");
            }
        }
    }
}
