﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bt17
{
    public class HinhTron
    {
        public Diem Tam { get; set; }
        public float BanKinh { get; set; }

        public HinhTron()
        {
            Tam = new Diem();
            BanKinh = 0;
        }

        public HinhTron(Diem tam, float banKinh)
        {
            Tam = tam;
            BanKinh = banKinh;
        }

        public float TinhChuVi()
        {
            return 2 * (float)Math.PI * BanKinh;
        }

        public float TinhDienTich()
        {
            return (float)Math.PI * BanKinh * BanKinh;
        }

        public void InHinhTron()
        {
            Console.Write("Hình tròn có tâm ");
            Tam.InDiem();
            Console.WriteLine($", bán kính = {BanKinh}");
        }

        // Kiểm tra giao nhau với hình tròn khác
        public bool GiaoNhau(HinhTron ht)
        {
            double khoangCachTam = Diem.KhoangCach(this.Tam, ht.Tam);
            float sumBanKinh = this.BanKinh + ht.BanKinh;
            float hieuBanKinh = Math.Abs(this.BanKinh - ht.BanKinh);

            // Hai hình tròn giao nhau khi khoảng cách tâm <= tổng bán kính và >= hiệu bán kính
            return khoangCachTam <= sumBanKinh && khoangCachTam >= hieuBanKinh;
        }
    }

}
