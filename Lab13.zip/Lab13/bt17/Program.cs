﻿using System;
using System.Text;
using bt17;

class Program
{
    static void Main()
    {
        Console.OutputEncoding = Encoding.UTF8;

        Console.Write("Nhập số lượng hình tròn: ");
        int n = int.Parse(Console.ReadLine());

        HinhTron[] dsHinhTron = new HinhTron[n];

        for (int i = 0; i < n; i++)
        {
            Console.WriteLine($"Nhập hình tròn thứ {i + 1}:");
            Diem tam = NhapDiem("Tâm");
            Console.Write("Nhập bán kính: ");
            float bk = float.Parse(Console.ReadLine());

            dsHinhTron[i] = new HinhTron(tam, bk);
        }

        // Đếm số hình tròn giao với mỗi hình tròn khác
        int maxGiao = 0;
        int idxHinhTronMaxGiao = -1;

        for (int i = 0; i < n; i++)
        {
            int dem = 0;
            for (int j = 0; j < n; j++)
            {
                if (i != j && dsHinhTron[i].GiaoNhau(dsHinhTron[j]))
                    dem++;
            }
            if (dem > maxGiao)
            {
                maxGiao = dem;
                idxHinhTronMaxGiao = i;
            }
        }

        if (idxHinhTronMaxGiao != -1)
        {
            Console.WriteLine("\nHình tròn giao với nhiều hình tròn khác nhất:");
            dsHinhTron[idxHinhTronMaxGiao].InHinhTron();
            Console.WriteLine($"Số lượng hình tròn giao: {maxGiao}");
        }
        else
        {
            Console.WriteLine("Không có hình tròn nào giao với hình tròn khác.");
        }

        Console.ReadKey();
    }

    static Diem NhapDiem(string tenDiem)
    {
        Console.WriteLine($"{tenDiem}:");
        Console.Write("  Nhập hoành độ x: ");
        double x = double.Parse(Console.ReadLine());
        Console.Write("  Nhập tung độ y: ");
        double y = double.Parse(Console.ReadLine());
        return new Diem(x, y);
    }
}
