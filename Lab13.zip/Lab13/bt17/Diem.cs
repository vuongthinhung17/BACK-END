﻿using System;
namespace bt17
{
      public class Diem
    {
        public double X { get; set; }
        public double Y { get; set; }

        public Diem()
        {
            X = 0;
            Y = 0;
        }

        public Diem(double x, double y)
        {
            X = x;
            Y = y;
        }

        public void InDiem()
        {
            Console.Write($"({X}, {Y})");
        }

        public static double KhoangCach(Diem a, Diem b)
        {
            return Math.Sqrt(Math.Pow(a.X - b.X, 2) + Math.Pow(a.Y - b.Y, 2));
        }
    }

}
