﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bt22
{
    class HocSinh
    {
        public string HoTen { get; set; }
        public int NamSinh { get; set; }
        public double TongDiem { get; set; }

        public void Nhap()
        {
            Console.Write("Họ tên: ");
            HoTen = Console.ReadLine();
            Console.Write("Năm sinh: ");
            NamSinh = int.Parse(Console.ReadLine());
            Console.Write("Tổng điểm: ");
            TongDiem = double.Parse(Console.ReadLine());
        }

        public void Xuat()
        {
            Console.WriteLine($"Họ tên: {ChuanHoaHoTen(HoTen),-30} | Năm sinh: {NamSinh} | Tổng điểm: {TongDiem}");
        }

        // Hàm chuẩn hóa tên: viết hoa chữ cái đầu
        public string ChuanHoaHoTen(string ten)
        {
            var tu = ten.ToLower().Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            for (int i = 0; i < tu.Length; i++)
            {
                tu[i] = CultureInfo.CurrentCulture.TextInfo.ToTitleCase(tu[i]);
            }
            return string.Join(" ", tu);
        }
    }

}
