﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using bt22;
class Program
{
    static void Main()
    {
        Console.OutputEncoding = System.Text.Encoding.UTF8;
        Console.InputEncoding = System.Text.Encoding.UTF8;

        List<HocSinh> danhSach = new List<HocSinh>();

        Console.Write("Nhập số lượng học sinh: ");
        int n = int.Parse(Console.ReadLine());

        for (int i = 0; i < n; i++)
        {
            Console.WriteLine($"\nNhập thông tin học sinh thứ {i + 1}:");
            HocSinh hs = new HocSinh();
            hs.Nhap();
            danhSach.Add(hs);
        }

        // Sắp xếp: tổng điểm giảm dần, nếu bằng thì năm sinh tăng dần
        danhSach.Sort((a, b) =>
        {
            int cmp = b.TongDiem.CompareTo(a.TongDiem);
            if (cmp == 0)
                return a.NamSinh.CompareTo(b.NamSinh);
            return cmp;
        });

        Console.WriteLine("\nDanh sách học sinh sau khi sắp xếp:");
        foreach (var hs in danhSach)
        {
            hs.Xuat();
        }
    }
}
