﻿using System;
namespace bt9
{
     public class KhachHang
    {
        public string HoTen { get; set; }
        public string SoNha { get; set; }
        public string MaCongTo { get; set; }

        public virtual void Nhap()
        {
            Console.Write("Nhập họ tên chủ hộ: ");
            HoTen = Console.ReadLine();
            Console.Write("Nhập số nhà: ");
            SoNha = Console.ReadLine();
            Console.Write("Nhập mã số công tơ: ");
            MaCongTo = Console.ReadLine();
        }

        public virtual void Xuat()
        {
            Console.WriteLine($"Họ tên: {HoTen}, Số nhà: {SoNha}, Mã công tơ: {MaCongTo}");
        }
    }

}
