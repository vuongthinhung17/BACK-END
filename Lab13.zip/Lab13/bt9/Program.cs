﻿using System;
using System.Collections.Generic;
using System.Text;
using bt9;

class Program
{

    static void Main()
    {
        Console.OutputEncoding = Encoding.UTF8;
        List<BienLai> danhSach = new List<BienLai>();

        while (true)
        {
            Console.WriteLine("\n------ MENU ------");
            Console.WriteLine("1. Nhập danh sách biên lai");
            Console.WriteLine("2. Hiển thị thông tin các biên lai");
            Console.WriteLine("3. Thoát");
            Console.Write("Chọn: ");
            string chon = Console.ReadLine();

            switch (chon)
            {
                case "1":
                    Console.Write("Nhập số hộ sử dụng điện: ");
                    int n = int.Parse(Console.ReadLine());
                    for (int i = 0; i < n; i++)
                    {
                        Console.WriteLine($"\nNhập thông tin hộ thứ {i + 1}:");
                        BienLai bl = new BienLai();
                        bl.Nhap();
                        danhSach.Add(bl);
                    }
                    break;

                case "2":
                    Console.WriteLine("\n--- DANH SÁCH BIÊN LAI ---");
                    foreach (var bl in danhSach)
                    {
                        bl.Xuat();
                        Console.WriteLine();
                    }
                    break;

                case "3":
                    return;

                default:
                    Console.WriteLine("Lựa chọn không hợp lệ. Vui lòng thử lại.");
                    break;
            }
        }
    }
}
