﻿using System;
namespace bt9
{
      public class BienLai : KhachHang
    {
        public int ChiSoCu { get; set; }
        public int ChiSoMoi { get; set; }

        public override void Nhap()
        {
            base.Nhap();
            Console.Write("Nhập chỉ số cũ: ");
            ChiSoCu = int.Parse(Console.ReadLine());
            Console.Write("Nhập chỉ số mới: ");
            ChiSoMoi = int.Parse(Console.ReadLine());
        }

        public override void Xuat()
        {
            base.Xuat();
            Console.WriteLine($"Chỉ số cũ: {ChiSoCu}, Chỉ số mới: {ChiSoMoi}");
            Console.WriteLine($"Tiền điện phải trả: {TinhTienDien()} VNĐ");
        }

        public double TinhTienDien()
        {
            int soDien = ChiSoMoi - ChiSoCu;
            double tien = 0;

            if (soDien <= 50)
                tien = soDien * 1250;
            else if (soDien <= 100)
                tien = 50 * 1250 + (soDien - 50) * 1500;
            else
                tien = 50 * 1250 + 50 * 1500 + (soDien - 100) * 2000;

            return tien;
        }
    }

}
