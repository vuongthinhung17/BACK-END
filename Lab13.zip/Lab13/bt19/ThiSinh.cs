﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bt19
{
       public struct HoTen
    {
        public string Ho;
        public string Dem;
        public string Ten;

        public override string ToString()
        {
            return $"{Ho} {Dem} {Ten}";
        }
    }

    public struct QueQuan
    {
        public string Xa;
        public string Huyen;
        public string Tinh;

        public override string ToString()
        {
            return $"{Xa}, {Huyen}, {Tinh}";
        }
    }

    public struct DiemThi
    {
        public float Toan;
        public float Ly;
        public float Hoa;

        public float TongDiem()
        {
            return Toan + Ly + Hoa;
        }
    }

    public class ThiSinh
    {
        public HoTen HoTen;
        public QueQuan QueQuan;
        public string Truong;
        public int Tuoi;
        public string SoBaoDanh;
        public DiemThi Diem;

        public void Nhap()
        {
            Console.WriteLine("Nhập thông tin thí sinh:");

            Console.Write("Họ: ");
            HoTen.Ho = Console.ReadLine();

            Console.Write("Tên đệm: ");
            HoTen.Dem = Console.ReadLine();

            Console.Write("Tên: ");
            HoTen.Ten = Console.ReadLine();

            Console.Write("Xã: ");
            QueQuan.Xa = Console.ReadLine();

            Console.Write("Huyện: ");
            QueQuan.Huyen = Console.ReadLine();

            Console.Write("Tỉnh: ");
            QueQuan.Tinh = Console.ReadLine();

            Console.Write("Trường: ");
            Truong = Console.ReadLine();

            Console.Write("Tuổi: ");
            Tuoi = int.Parse(Console.ReadLine());

            Console.Write("Số báo danh: ");
            SoBaoDanh = Console.ReadLine();

            Console.Write("Điểm Toán: ");
            Diem.Toan = float.Parse(Console.ReadLine());

            Console.Write("Điểm Lý: ");
            Diem.Ly = float.Parse(Console.ReadLine());

            Console.Write("Điểm Hóa: ");
            Diem.Hoa = float.Parse(Console.ReadLine());
        }

        public void In()
        {
            Console.WriteLine($"{HoTen,-20} | {QueQuan,-30} | {SoBaoDanh,-10} | " +
                              $"{Diem.Toan,5:F2} | {Diem.Ly,5:F2} | {Diem.Hoa,5:F2} | Tổng: {Diem.TongDiem(),5:F2}");
        }
    }

}
