﻿using System;
using System.Collections.Generic;
using System.Text;
using bt19;

class Program
{
    static void Main()
    {
        Console.OutputEncoding = System.Text.Encoding.UTF8;
        Console.InputEncoding = System.Text.Encoding.UTF8;

        List<ThiSinh> danhSach = new List<ThiSinh>();

        Console.Write("Nhập số lượng thí sinh: ");
        int n = int.Parse(Console.ReadLine());

        for (int i = 0; i < n; i++)
        {
            Console.WriteLine($"\nThí sinh thứ {i + 1}:");
            ThiSinh ts = new ThiSinh();
            ts.Nhap();
            danhSach.Add(ts);
        }

        Console.WriteLine("\nDanh sách thí sinh có tổng điểm > 15:");
        foreach (var ts in danhSach)
        {
            if (ts.Diem.TongDiem() > 15)
                ts.In();
        }

        Console.WriteLine("\nDanh sách thí sinh sau khi sắp xếp giảm dần theo tổng điểm:");
        danhSach.Sort((a, b) => b.Diem.TongDiem().CompareTo(a.Diem.TongDiem()));

        Console.WriteLine("\n{0,-20} | {1,-30} | {2,-10} | {3,5} | {4,5} | {5,5} | {6,8}",
            "Họ tên", "Quê quán", "SBD", "Toán", "Lý", "Hóa", "Tổng");

        foreach (var ts in danhSach)
        {
            Console.WriteLine("{0,-20} | {1,-30} | {2,-10} | {3,5:F2} | {4,5:F2} | {5,5:F2} | {6,8:F2}",
                ts.HoTen, ts.QueQuan, ts.SoBaoDanh, ts.Diem.Toan, ts.Diem.Ly, ts.Diem.Hoa, ts.Diem.TongDiem());
        }
    }
}
