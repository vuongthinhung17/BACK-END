﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bt5
{
     public class KhachSan
        {
            private List<KhachThue> danhSachKhach;

            public KhachSan()
            {
                danhSachKhach = new List<KhachThue>();
            }

            public void NhapDanhSach()
            {
                Console.Write("Nhập số lượng khách thuê phòng: ");
                int n = int.Parse(Console.ReadLine());

                for (int i = 0; i < n; i++)
                {
                    Console.WriteLine($"\n>> Nhập khách thứ {i + 1}:");
                    KhachThue kt = new KhachThue();
                    kt.Nhap();
                    danhSachKhach.Add(kt);
                }
            }

            public void HienThiDanhSach()
            {
                Console.WriteLine("\n=== DANH SÁCH KHÁCH THUÊ PHÒNG ===");
                foreach (var khach in danhSachKhach)
                {
                    khach.Xuat();
                    Console.WriteLine("----------------------------------");
                }
            }

            public void TimTheoTen(string ten)
            {
                bool timThay = false;
                foreach (var khach in danhSachKhach)
                {
                    if (khach.ThongTinCaNhan.HoTen.ToLower().Contains(ten.ToLower()))
                    {
                        khach.Xuat();
                        Console.WriteLine("----------------------------------");
                        timThay = true;
                    }
                }

                if (!timThay)
                {
                    Console.WriteLine("Không tìm thấy khách nào có tên như vậy.");
                }
            }

            public void TinhTienTheoTen(string ten)
            {
                foreach (var khach in danhSachKhach)
                {
                    if (khach.ThongTinCaNhan.HoTen.ToLower().Contains(ten.ToLower()))
                    {
                        double tongTien = khach.TinhTien();
                        Console.WriteLine($"\nKhách: {khach.ThongTinCaNhan.HoTen} cần thanh toán: {tongTien} VNĐ");
                        return;
                    }
                }
                Console.WriteLine("Không tìm thấy khách hàng cần thanh toán.");
            }
        }
    }

