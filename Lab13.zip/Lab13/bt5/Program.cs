﻿using System;
using bt5;

namespace QuanLyKhachSan
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = System.Text.Encoding.UTF8;
            KhachSan ks = new KhachSan();

            while (true)
            {
                Console.WriteLine("\n===== MENU QUẢN LÝ KHÁCH SẠN =====");
                Console.WriteLine("1. Nhập danh sách khách thuê phòng");
                Console.WriteLine("2. Hiển thị danh sách khách thuê phòng");
                Console.WriteLine("3. Tìm kiếm khách theo họ tên");
                Console.WriteLine("4. Tính tiền thanh toán cho khách");
                Console.WriteLine("5. Thoát");
                Console.Write("Chọn chức năng: ");
                string chon = Console.ReadLine();

                switch (chon)
                {
                    case "1":
                        ks.NhapDanhSach();
                        break;
                    case "2":
                        ks.HienThiDanhSach();
                        break;
                    case "3":
                        Console.Write("Nhập họ tên khách cần tìm: ");
                        ks.TimTheoTen(Console.ReadLine());
                        break;
                    case "4":
                        Console.Write("Nhập họ tên khách cần thanh toán: ");
                        ks.TinhTienTheoTen(Console.ReadLine());
                        break;
                    case "5":
                        return;
                    default:
                        Console.WriteLine("Lựa chọn không hợp lệ.");
                        break;
                }
            }
        }
    }
}
