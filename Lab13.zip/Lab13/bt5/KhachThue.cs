﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bt5
{
    public class KhachThue
        {
            public Nguoi ThongTinCaNhan { get; set; }
            public string LoaiPhong { get; set; }
            public int SoNgayTro { get; set; }
            public double GiaPhongMotNgay { get; set; }

            public KhachThue()
            {
                ThongTinCaNhan = new Nguoi();
            }

            public void Nhap()
            {
                Console.WriteLine("Nhập thông tin cá nhân:");
                ThongTinCaNhan.Nhap();
                Console.Write("  - Loại phòng (A/B/C...): "); LoaiPhong = Console.ReadLine();
                Console.Write("  - Số ngày trọ: "); SoNgayTro = int.Parse(Console.ReadLine());
                Console.Write("  - Giá phòng mỗi ngày: "); GiaPhongMotNgay = double.Parse(Console.ReadLine());
            }

            public void Xuat()
            {
                ThongTinCaNhan.Xuat();
                Console.WriteLine($"  + Loại phòng: {LoaiPhong}, Số ngày trọ: {SoNgayTro}, Giá/ngày: {GiaPhongMotNgay} VNĐ");
            }

            public double TinhTien()
            {
                return SoNgayTro * GiaPhongMotNgay;
            }
        }
    }
