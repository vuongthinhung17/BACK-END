﻿using System;
using bt4;

namespace QuanLyKhuPho
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = System.Text.Encoding.UTF8;
            KhuPho khuPho = new KhuPho();

            while (true)
            {
                Console.WriteLine("\n========= MENU =========");
                Console.WriteLine("1. Nhập danh sách hộ dân");
                Console.WriteLine("2. Hiển thị toàn bộ hộ dân");
                Console.WriteLine("3. Tìm kiếm theo họ tên");
                Console.WriteLine("4. Tìm kiếm theo số nhà");
                Console.WriteLine("5. Thoát");
                Console.Write("Chọn chức năng: ");
                string chon = Console.ReadLine();

                switch (chon)
                {
                    case "1":
                        khuPho.NhapDanhSach();
                        break;
                    case "2":
                        khuPho.HienThiDanhSach();
                        break;
                    case "3":
                        Console.Write("Nhập họ tên cần tìm: ");
                        string hoTen = Console.ReadLine();
                        khuPho.TimTheoHoTen(hoTen);
                        break;
                    case "4":
                        Console.Write("Nhập số nhà cần tìm: ");
                        int soNha = int.Parse(Console.ReadLine());
                        khuPho.TimTheoSoNha(soNha);
                        break;
                    case "5":
                        return;
                    default:
                        Console.WriteLine("Lựa chọn không hợp lệ.");
                        break;
                }
            }
        }
    }
}
