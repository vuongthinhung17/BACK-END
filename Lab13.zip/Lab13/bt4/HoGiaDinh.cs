﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bt4
{
        public class HoGiaDinh
        {
            public int SoNha { get; set; }
            public List<Nguoi> ThanhVien { get; set; }

            public HoGiaDinh()
            {
                ThanhVien = new List<Nguoi>();
            }

            public void Nhap()
            {
                Console.Write("Nhập số nhà: ");
                SoNha = int.Parse(Console.ReadLine());

                Console.Write("Nhập số thành viên: ");
                int n = int.Parse(Console.ReadLine());

                for (int i = 0; i < n; i++)
                {
                    Console.WriteLine($"\n  >> Nhập thông tin thành viên {i + 1}:");
                    Nguoi nguoi = new Nguoi();
                    nguoi.Nhap();
                    ThanhVien.Add(nguoi);
                }
            }

            public void Xuat()
            {
                Console.WriteLine($"\n🏡 Số nhà: {SoNha} | Số thành viên: {ThanhVien.Count}");
                foreach (var tv in ThanhVien)
                {
                    tv.Xuat();
                }
            }

            public bool ChuaNguoiTen(string ten)
            {
                return ThanhVien.Exists(tv => tv.HoTen.ToLower().Contains(ten.ToLower()));
            }
        }
    }


