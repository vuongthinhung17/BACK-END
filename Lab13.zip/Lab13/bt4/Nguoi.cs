﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bt4
{
        public class Nguoi
        {
            public string HoTen { get; set; }
            public int Tuoi { get; set; }
            public string NgheNghiep { get; set; }
            public string SoCMND { get; set; }

            public void Nhap()
            {
                Console.Write("  - Họ tên: "); HoTen = Console.ReadLine();
                Console.Write("  - Tuổi: "); Tuoi = int.Parse(Console.ReadLine());
                Console.Write("  - Nghề nghiệp: "); NgheNghiep = Console.ReadLine();
                Console.Write("  - Số CMND: "); SoCMND = Console.ReadLine();
            }

            public void Xuat()
            {
                Console.WriteLine($"  + {HoTen} | Tuổi: {Tuoi} | Nghề: {NgheNghiep} | CMND: {SoCMND}");
            }
        }
    }


