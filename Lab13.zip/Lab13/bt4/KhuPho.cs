﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bt4
{
        public class KhuPho
        {
            private List<HoGiaDinh> danhSachHo;

            public KhuPho()
            {
                danhSachHo = new List<HoGiaDinh>();
            }

            public void NhapDanhSach()
            {
                Console.Write("Nhập số hộ dân: ");
                int n = int.Parse(Console.ReadLine());

                for (int i = 0; i < n; i++)
                {
                    Console.WriteLine($"\n>> Nhập hộ dân thứ {i + 1}:");
                    HoGiaDinh ho = new HoGiaDinh();
                    ho.Nhap();
                    danhSachHo.Add(ho);
                }
            }

            public void HienThiDanhSach()
            {
                Console.WriteLine("\n=== DANH SÁCH HỘ DÂN TRONG KHU PHỐ ===");
                foreach (var ho in danhSachHo)
                {
                    ho.Xuat();
                }
            }

            public void TimTheoHoTen(string hoTen)
            {
                Console.WriteLine($"\nKết quả tìm kiếm theo tên \"{hoTen}\":");
                bool found = false;
                foreach (var ho in danhSachHo)
                {
                    if (ho.ChuaNguoiTen(hoTen))
                    {
                        ho.Xuat();
                        found = true;
                    }
                }
                if (!found) Console.WriteLine("Không tìm thấy hộ dân nào chứa tên này.");
            }

            public void TimTheoSoNha(int soNha)
            {
                var ho = danhSachHo.Find(h => h.SoNha == soNha);
                if (ho != null)
                {
                    Console.WriteLine("\nKết quả tìm kiếm:");
                    ho.Xuat();
                }
                else
                {
                    Console.WriteLine("Không tìm thấy hộ dân có số nhà này.");
                }
            }
        }
    }


