﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bt8
{
  
    public class SinhVien
    {
        public string HoTen { get; set; }
        public int NamSinh { get; set; }
        public string Lop { get; set; }
        public string MaSV { get; set; }

        public void Nhap()
        {
            Console.Write("Họ tên: ");
            HoTen = Console.ReadLine();
            Console.Write("Năm sinh: ");
            NamSinh = int.Parse(Console.ReadLine());
            Console.Write("Lớp: ");
            Lop = Console.ReadLine();
            Console.Write("Mã số sinh viên: ");
            MaSV = Console.ReadLine();
        }

        public void Xuat()
        {
            Console.WriteLine($"Họ tên: {HoTen}");
            Console.WriteLine($"Năm sinh: {NamSinh}");
            Console.WriteLine($"Lớp: {Lop}");
            Console.WriteLine($"Mã SV: {MaSV}");
        }
    }

}
