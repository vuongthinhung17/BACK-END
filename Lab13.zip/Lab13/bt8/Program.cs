﻿using System;
using System.Collections.Generic;
using System.Text;
using bt8;

class Program
{
    static void Main()
    {
        Console.OutputEncoding = Encoding.UTF8;
        List<TheMuon> danhSach = new List<TheMuon>();

        while (true)
        {
            Console.WriteLine("\n===== MENU =====");
            Console.WriteLine("1. Nhập danh sách thẻ mượn");
            Console.WriteLine("2. Tìm sinh viên theo mã số sinh viên");
            Console.WriteLine("3. Hiển thị sinh viên đến hạn trả sách");
            Console.WriteLine("4. Thoát");
            Console.Write("Chọn: ");
            string luaChon = Console.ReadLine();

            switch (luaChon)
            {
                case "1":
                    Console.Write("Nhập số lượng sinh viên: ");
                    int n = int.Parse(Console.ReadLine());
                    for (int i = 0; i < n; i++)
                    {
                        Console.WriteLine($"\n--- Sinh viên thứ {i + 1} ---");
                        TheMuon tm = new TheMuon();
                        tm.Nhap();
                        danhSach.Add(tm);
                    }
                    break;

                case "2":
                    Console.Write("Nhập mã số sinh viên: ");
                    string maSV = Console.ReadLine();
                    var ketQua = danhSach.FindAll(tm => tm.SinhVien.MaSV == maSV);
                    if (ketQua.Count == 0)
                        Console.WriteLine("Không tìm thấy.");
                    else
                        ketQua.ForEach(tm => tm.Xuat());
                    break;

                case "3":
                    DateTime now = DateTime.Now.Date;
                    var quaHan = danhSach.FindAll(tm => tm.HanTra.Date <= now);
                    if (quaHan.Count == 0)
                        Console.WriteLine("Không có sinh viên nào đến hạn trả sách.");
                    else
                        quaHan.ForEach(tm => tm.Xuat());
                    break;

                case "4":
                    return;

                default:
                    Console.WriteLine("Lựa chọn không hợp lệ!");
                    break;
            }
        }
    }
}
