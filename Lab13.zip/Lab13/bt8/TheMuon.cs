﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bt8
{
    public class TheMuon
    {
        public string SoPhieuMuon { get; set; }
        public DateTime NgayMuon { get; set; }
        public DateTime HanTra { get; set; }
        public string SoHieuSach { get; set; }
        public SinhVien SinhVien { get; set; }

        public void Nhap()
        {
            Console.Write("Số phiếu mượn: ");
            SoPhieuMuon = Console.ReadLine();
            Console.Write("Ngày mượn (yyyy-MM-dd): ");
            NgayMuon = DateTime.Parse(Console.ReadLine());
            Console.Write("Hạn trả (yyyy-MM-dd): ");
            HanTra = DateTime.Parse(Console.ReadLine());
            Console.Write("Số hiệu sách: ");
            SoHieuSach = Console.ReadLine();

            SinhVien = new SinhVien();
            Console.WriteLine("=== Nhập thông tin sinh viên ===");
            SinhVien.Nhap();
        }

        public void Xuat()
        {
            Console.WriteLine("\n--- Thông tin thẻ mượn ---");
            Console.WriteLine($"Số phiếu mượn: {SoPhieuMuon}");
            Console.WriteLine($"Ngày mượn: {NgayMuon.ToShortDateString()}");
            Console.WriteLine($"Hạn trả: {HanTra.ToShortDateString()}");
            Console.WriteLine($"Số hiệu sách: {SoHieuSach}");
            SinhVien.Xuat();
        }
    }

}
