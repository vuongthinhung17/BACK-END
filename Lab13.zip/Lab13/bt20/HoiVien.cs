﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bt20
{
    public class HoiVien
    {
        public string HoTen { get; set; }
        public string DiaChi { get; set; }

        public virtual void Nhap()
        {
            Console.Write("Họ tên: ");
            HoTen = Console.ReadLine();
            Console.Write("Địa chỉ: ");
            DiaChi = Console.ReadLine();
        }

        public virtual void Xuat()
        {
            Console.WriteLine($"Họ tên: {HoTen} | Địa chỉ: {DiaChi}");
        }
    }

}
