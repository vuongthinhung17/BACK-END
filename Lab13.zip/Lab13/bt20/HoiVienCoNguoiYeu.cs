﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bt20
{
    public class HoiVienCoNguoiYeu : HoiVien
    {
        public string TenNguoiYeu { get; set; }
        public string SDTNguoiYeu { get; set; }

        public override void Nhap()
        {
            base.Nhap();
            Console.Write("Tên người yêu: ");
            TenNguoiYeu = Console.ReadLine();
            Console.Write("SĐT người yêu: ");
            SDTNguoiYeu = Console.ReadLine();
        }

        public override void Xuat()
        {
            base.Xuat();
            Console.WriteLine($"Người yêu: {TenNguoiYeu} | SĐT: {SDTNguoiYeu}");
        }
    }

}
