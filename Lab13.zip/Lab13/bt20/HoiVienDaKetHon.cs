﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bt20
{
    public class HoiVienDaKetHon : HoiVien
    {
        public string TenVo { get; set; }
        public DateTime NgayCuoi { get; set; }

        public override void Nhap()
        {
            base.Nhap();
            Console.Write("Tên vợ/chồng: ");
            TenVo = Console.ReadLine();
            Console.Write("Ngày cưới (dd/MM/yyyy): ");
            NgayCuoi = DateTime.ParseExact(Console.ReadLine(), "dd/MM/yyyy", null);
        }

        public override void Xuat()
        {
            base.Xuat();
            Console.WriteLine($"Vợ/Chồng: {TenVo} | Ngày cưới: {NgayCuoi:dd/MM/yyyy}");
        }
    }

}
