﻿using System;
using System.Collections.Generic;
using System.Text;
using bt20;

class Program
{
    static void Main()
    {
        Console.OutputEncoding = Encoding.UTF8;

        List<HoiVien> danhSach = new List<HoiVien>();
        Console.Write("Nhập số hội viên: ");
        int n = int.Parse(Console.ReadLine());

        for (int i = 0; i < n; i++)
        {
            Console.WriteLine($"\nHội viên thứ {i + 1}:");
            Console.WriteLine("1. Chưa có người yêu");
            Console.WriteLine("2. Có người yêu");
            Console.WriteLine("3. Đã kết hôn");
            Console.Write("Chọn loại hội viên (1-3): ");
            int loai = int.Parse(Console.ReadLine());

            HoiVien hv;
            if (loai == 2)
                hv = new HoiVienCoNguoiYeu();
            else if (loai == 3)
                hv = new HoiVienDaKetHon();
            else
                hv = new HoiVien();

            hv.Nhap();
            danhSach.Add(hv);
        }

        // 3. Tìm hội viên cưới ngày 11.11.2011
        Console.WriteLine("\nHội viên cưới ngày 11/11/2011:");
        foreach (var hv in danhSach)
        {
            if (hv is HoiVienDaKetHon daKetHon &&
                daKetHon.NgayCuoi == new DateTime(2011, 11, 11))
            {
                daKetHon.Xuat();
            }
        }

        // 4. Hội viên có người yêu nhưng chưa cưới
        Console.WriteLine("\nHội viên có người yêu nhưng chưa lập gia đình:");
        foreach (var hv in danhSach)
        {
            if (hv is HoiVienCoNguoiYeu)
            {
                hv.Xuat();
            }
        }
    }
}

