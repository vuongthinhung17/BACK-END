﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

class Program
{
    static void Main()
    {
        Console.OutputEncoding = Encoding.UTF8;

        List<CBGV> danhSachCBGV = new List<CBGV>();

        while (true)
        {
            Console.WriteLine("\n====== MENU ======");
            Console.WriteLine("1. Nhập danh sách cán bộ giáo viên");
            Console.WriteLine("2. Tìm theo quê quán");
            Console.WriteLine("3. Hiển thị cán bộ có lương thực lĩnh > 5 triệu");
            Console.WriteLine("4. Thoát");
            Console.Write("Chọn chức năng: ");
            string luaChon = Console.ReadLine();

            switch (luaChon)
            {
                case "1":
                    Console.Write("Nhập số lượng cán bộ giáo viên: ");
                    int n = int.Parse(Console.ReadLine());

                    for (int i = 0; i < n; i++)
                    {
                        Console.WriteLine($"\nNhập cán bộ thứ {i + 1}:");
                        CBGV cb = new CBGV();
                        cb.Nhap();
                        danhSachCBGV.Add(cb);
                    }
                    break;

                case "2":
                    Console.Write("Nhập quê quán cần tìm: ");
                    string que = Console.ReadLine();
                    var timQue = danhSachCBGV.Where(cb => cb.QueQuan.ToLower().Contains(que.ToLower()));
                    foreach (var cb in timQue)
                    {
                        cb.Xuat();
                        Console.WriteLine("---------------------");
                    }
                    break;

                case "3":
                    var luongCao = danhSachCBGV.Where(cb => cb.LuongThucLinh > 5000000);
                    foreach (var cb in luongCao)
                    {
                        cb.Xuat();
                        Console.WriteLine("---------------------");
                    }
                    break;

                case "4":
                    Console.WriteLine("Đã thoát chương trình.");
                    return;

                default:
                    Console.WriteLine("Lựa chọn không hợp lệ.");
                    break;
            }
        }
    }
}
