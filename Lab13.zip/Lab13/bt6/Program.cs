﻿using System;
using System.Collections.Generic;

namespace bt6;

class Program
{
    static void Main(string[] args)
    {
        Console.OutputEncoding = System.Text.Encoding.UTF8;
        List<HSHocSinh> list = new List<HSHocSinh>();
        while (true) 
        {
            Console.WriteLine("\n=====MENU QUẢN LÝ HỒ SƠ HỌC SINH=====");
            Console.WriteLine("1.Nhập danh sách học sinh: ");
            Console.WriteLine("2. Hiển thị học sinh nữ sinh năm 1985: ");
            Console.WriteLine("3.Tìm kiếm học sinh theo quê quán:");
            Console.WriteLine("4.Thoát");
            string chon = Console.ReadLine();
            switch (chon)
            {
                case "1":
                    Console.Write("Nhập số lượng học sinh: ");
                    int n = int.Parse(Console.ReadLine());
                    for (int i = 0; i < n; i++)
                    {
                        Console.WriteLine($"\n>> Nhập học sinh thứ {i + 1}:");
                        HSHocSinh hs = new HSHocSinh();
                        hs.Nhap();
                        list.Add(hs);
                    }
                    break;

                case "2":
                    Console.WriteLine("\n--- Danh sách học sinh nữ sinh năm 1985 ---");
                    foreach (var hs in list)
                    {
                        string gt = hs.GioiTinh.Trim().ToLower();
                        if ((gt == "nữ" || gt == "nu") && hs.NamSinh == 1985)

                        {
                            hs.Xuat();
                            Console.WriteLine("--------------------------------");
                        }
                    }
                    break;

                case "3":
                    Console.Write("Nhập quê quán cần tìm: ");
                    string que = Console.ReadLine().ToLower();
                    bool timThay = false;
                    foreach (var hs in list)
                    {
                        if (hs.QueQuan.ToLower().Contains(que))
                        {
                            hs.Xuat();
                            Console.WriteLine("--------------------------------");
                            timThay = true;
                        }
                    }
                    if (!timThay)
                        Console.WriteLine("Không tìm thấy học sinh nào từ quê quán này.");
                    break;

                case "4":
                    return;

                default:
                    Console.WriteLine("Chức năng không hợp lệ.");
                    break;
            }
        }
    }
}
