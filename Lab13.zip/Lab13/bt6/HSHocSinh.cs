﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bt6
{
    public class HSHocSinh : Nguoi
    {
        public string Lop { get; set; }
        public string KhoaHoc { get; set; }
        public string KyHoc { get; set; }
        public override void Nhap()
        {
            base.Nhap();
            Console.WriteLine(" - Lớp:");
            Lop = Console.ReadLine();
            Console.WriteLine(" - Khoá học:");
            KhoaHoc = Console.ReadLine();
            Console.WriteLine(" - Kỳ học:");
            KyHoc = Console.ReadLine();
        }
        public override void Xuat()
        {
            base.Xuat();
            Console.WriteLine($" + Lớp:{Lop} ,Khoá học: {KhoaHoc}, Kỳ học:{KyHoc}");    
        }
    }

}