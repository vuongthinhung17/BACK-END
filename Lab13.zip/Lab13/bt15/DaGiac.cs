﻿using System;

namespace bt15
{
       public class DaGiac
    {
        protected int soCanh;
        protected int[] cacCanh;

        public DaGiac()
        {
            soCanh = 0;
            cacCanh = new int[0];
        }

        public DaGiac(int soCanh, int[] cacCanh)
        {
            this.soCanh = soCanh;
            this.cacCanh = new int[soCanh];
            Array.Copy(cacCanh, this.cacCanh, soCanh);
        }

        public virtual int TinhChuVi()
        {
            int chuVi = 0;
            for (int i = 0; i < soCanh; i++)
                chuVi += cacCanh[i];
            return chuVi;
        }

        public virtual void InCacCanh()
        {
            Console.Write("Các cạnh đa giác: ");
            for (int i = 0; i < soCanh; i++)
            {
                Console.Write(cacCanh[i]);
                if (i != soCanh - 1) Console.Write(", ");
            }
            Console.WriteLine();
        }

        public int[] GetCacCanh()
        {
            return cacCanh;
        }
    }

}
