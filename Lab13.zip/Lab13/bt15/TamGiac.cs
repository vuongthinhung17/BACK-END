﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bt15
{
    using System;

    public class TamGiac : DaGiac
    {
        public TamGiac() : base()
        {
            soCanh = 3;
            cacCanh = new int[3];
        }

        public TamGiac(int[] cacCanh) : base(3, cacCanh)
        {
            soCanh = 3;
        }

        public override int TinhChuVi()
        {
            int chuVi = 0;
            for (int i = 0; i < 3; i++)
                chuVi += cacCanh[i];
            return chuVi;
        }

        public double TinhDienTich()
        {
            double p = TinhChuVi() / 2.0;
            double a = cacCanh[0];
            double b = cacCanh[1];
            double c = cacCanh[2];
            double dienTich = Math.Sqrt(p * (p - a) * (p - b) * (p - c));
            return dienTich;
        }

        public bool KiemTraPythagore()
        {
            int[] canh = new int[3];
            Array.Copy(cacCanh, canh, 3);
            Array.Sort(canh);
            int a = canh[0];
            int b = canh[1];
            int c = canh[2];
            return a * a + b * b == c * c;
        }
    }

}
