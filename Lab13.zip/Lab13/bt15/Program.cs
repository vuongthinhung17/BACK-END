﻿using System;
using System.Text;
using bt15;

class Program
{
    static void Main()
    {
        Console.OutputEncoding = Encoding.UTF8;

        Console.Write("Nhập số lượng tam giác: ");
        int n = int.Parse(Console.ReadLine());
        TamGiac[] dsTamGiac = new TamGiac[n];

        for (int i = 0; i < n; i++)
        {
            Console.WriteLine($"Nhập 3 cạnh tam giác thứ {i + 1}:");
            int[] canh = new int[3];
            for (int j = 0; j < 3; j++)
            {
                Console.Write($"Cạnh {j + 1}: ");
                canh[j] = int.Parse(Console.ReadLine());
            }
            dsTamGiac[i] = new TamGiac(canh);
        }

        Console.WriteLine("\nCác tam giác thỏa mãn định lý Pythagore:");
        bool found = false;
        for (int i = 0; i < n; i++)
        {
            if (dsTamGiac[i].KiemTraPythagore())
            {
                found = true;
                Console.Write($"Tam giác {i + 1}: ");
                dsTamGiac[i].InCacCanh();
            }
        }

        if (!found)
            Console.WriteLine("Không có tam giác nào thỏa mãn định lý Pythagore.");

        Console.ReadKey();
    }
}
