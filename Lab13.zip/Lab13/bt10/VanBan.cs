﻿using System;
using System.Collections.Generic;
 using System.Text.RegularExpressions;

namespace bt10
{
      public class VanBan
    {
        private string noiDung;

        // Hàm tạo không đối số
        public VanBan()
        {
            noiDung = "";
        }

        // Hàm tạo có đối số
        public VanBan(string st)
        {
            noiDung = st;
        }

        // Phương thức đếm số từ
        public int DemSoTu()
        {
            if (string.IsNullOrWhiteSpace(noiDung))
                return 0;

            string[] tu = noiDung.Trim().Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            return tu.Length;
        }

        // Phương thức đếm số ký tự 'H' (không phân biệt hoa thường)
        public int DemKyTuH()
        {
            int count = 0;
            foreach (char c in noiDung)
            {
                if (char.ToUpper(c) == 'H')
                    count++;
            }
            return count;
        }

        // Phương thức chuẩn hoá xâu (xoá khoảng trắng thừa)
        public string ChuanHoa()
        {
            string chuanHoa = Regex.Replace(noiDung.Trim(), @"\s+", " ");
            return chuanHoa;
        }

        // Getter/Setter nếu cần sử dụng trong menu
        public string NoiDung
        {
            get { return noiDung; }
            set { noiDung = value; }
        }
    }

}
