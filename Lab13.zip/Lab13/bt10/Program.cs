﻿using System;
using System.Text;
using bt10;

class Program
{
    static void Main()
    {
        Console.OutputEncoding = Encoding.UTF8;
        VanBan vb = new VanBan();

        Console.Write("Nhập văn bản: ");
        vb.NoiDung = Console.ReadLine();

        int luaChon;
        do
        {
            Console.WriteLine("\n===== MENU =====");
            Console.WriteLine("1. Đếm số từ");
            Console.WriteLine("2. Đếm số ký tự 'H'");
            Console.WriteLine("3. Chuẩn hoá xâu");
            Console.WriteLine("4. Thoát");
            Console.Write("Nhập lựa chọn của bạn: ");
            luaChon = int.Parse(Console.ReadLine());

            switch (luaChon)
            {
                case 1:
                    Console.WriteLine("Số từ: " + vb.DemSoTu());
                    break;
                case 2:
                    Console.WriteLine("Số ký tự 'H' hoặc 'h': " + vb.DemKyTuH());
                    break;
                case 3:
                    Console.WriteLine("Chuỗi sau khi chuẩn hoá: \"" + vb.ChuanHoa() + "\"");
                    break;
                case 4:
                    Console.WriteLine("Thoát chương trình.");
                    break;
                default:
                    Console.WriteLine("Lựa chọn không hợp lệ.");
                    break;
            }

        } while (luaChon != 4);
    }
}
