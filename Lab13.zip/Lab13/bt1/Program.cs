﻿using System.Text;
public class Program
{
    public static void Main(string[] args)
    {
        Console.OutputEncoding = System.Text.Encoding.UTF8;

        QLCB qlcb = new QLCB();
        bool running = true;

        while (running)
        {
            Console.WriteLine("\n--- CHƯƠNG TRÌNH QUẢN LÝ CÁN BỘ ---");
            Console.WriteLine("1. Nhập thông tin cán bộ mới");
            Console.WriteLine("2. Tìm kiếm cán bộ theo họ tên");
            Console.WriteLine("3. Hiển thị danh sách cán bộ");
            Console.WriteLine("4. Thoát chương trình");
            Console.Write("Chọn chức năng (1-4): ");
            string choice = Console.ReadLine();

            switch (choice)
            {
                case "1":
                    qlcb.NhapThongTinMoi();
                    break;
                case "2":
                    qlcb.TimKiemTheoHoTen();
                    break;
                case "3":
                    qlcb.HienThiDanhSachCanBo();
                    break;
                case "4":
                    running = false;
                    Console.WriteLine("Đang thoát chương trình...");
                    break;
                default:
                    Console.WriteLine("Lựa chọn không hợp lệ. Vui lòng nhập số từ 1 đến 4.");
                    break;
            }
            Console.WriteLine("\nNhấn phím bất kỳ để tiếp tục...");
            Console.ReadKey();
            Console.Clear(); // Xóa màn hình console để giao diện sạch sẽ hơn
        }
    }
}