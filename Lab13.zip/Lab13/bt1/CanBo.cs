﻿using System;
using System.Collections.Generic;
using System.Linq;

class CanBo
{
    public string HoTen { get; set; }
    public int NamSinh { get; set; }
    public string GioiTinh { get; set; }
    public string DiaChi { get; set; }

    public virtual void Nhap()
    {
        Console.Write("Họ tên: ");
        HoTen = Console.ReadLine();
        Console.Write("Năm sinh: ");
        NamSinh = int.Parse(Console.ReadLine() ?? "0");
        Console.Write("Giới tính: ");
        GioiTinh = Console.ReadLine();
        Console.Write("Địa chỉ: ");
        DiaChi = Console.ReadLine();
    }

    public virtual void HienThi()
    {
        Console.WriteLine($"Họ tên: {HoTen}, Năm sinh: {NamSinh}, Giới tính: {GioiTinh}, Địa chỉ: {DiaChi}");
    }
}

class CongNhan : CanBo
{
    public int Bac { get; set; }

    public override void Nhap()
    {
        base.Nhap();
        Console.Write("Bậc (1-7): ");
        Bac = int.Parse(Console.ReadLine() ?? "0");
    }

    public override void HienThi()
    {
        base.HienThi();
        Console.WriteLine($"Bậc công nhân: {Bac}/7");
    }
}

class KySu : CanBo
{
    public string NganhDaoTao { get; set; }

    public override void Nhap()
    {
        base.Nhap();
        Console.Write("Ngành đào tạo: ");
        NganhDaoTao = Console.ReadLine();
    }

    public override void HienThi()
    {
        base.HienThi();
        Console.WriteLine($"Ngành đào tạo: {NganhDaoTao}");
    }
}

class NhanVien : CanBo
{
    public string CongViec { get; set; }

    public override void Nhap()
    {
        base.Nhap();
        Console.Write("Công việc: ");
        CongViec = Console.ReadLine();
    }

    public override void HienThi()
    {
        base.HienThi();
        Console.WriteLine($"Công việc: {CongViec}");
    }
}

class QLCB
{
    private List<CanBo> danhSach = new List<CanBo>();

    public void NhapCanBo()
    {
        Console.WriteLine("\nChọn loại cán bộ cần nhập:");
        Console.WriteLine("1. Công nhân");
        Console.WriteLine("2. Kỹ sư");
        Console.WriteLine("3. Nhân viên");
        Console.Write("Lựa chọn: ");
        string chon = Console.ReadLine();

        CanBo cb = null;
        switch (chon)
        {
            case "1":
                cb = new CongNhan();
                break;
            case "2":
                cb = new KySu();
                break;
            case "3":
                cb = new NhanVien();
                break;
            default:
                Console.WriteLine("Lựa chọn không hợp lệ!");
                return;
        }

        cb.Nhap();
        danhSach.Add(cb);
        Console.WriteLine("-> Thêm cán bộ thành công!\n");
    }

    public void TimKiemTheoHoTen()
    {
        Console.Write("Nhập họ tên cần tìm: ");
        string hoTen = Console.ReadLine();
        var ketQua = danhSach.Where(cb => cb.HoTen.Equals(hoTen, StringComparison.OrdinalIgnoreCase)).ToList();

        if (ketQua.Any())
        {
            Console.WriteLine("\nKết quả tìm kiếm:");
            foreach (var cb in ketQua)
                cb.HienThi();
        }
        else
        {
            Console.WriteLine("-> Không tìm thấy cán bộ nào.");
        }
    }

    public void HienThiDanhSach()
    {
        Console.WriteLine("\n--- Danh sách cán bộ ---");
        foreach (var cb in danhSach)
        {
            cb.HienThi();
            Console.WriteLine();
        }
    }
}

