﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab13
{
    internal class TaiLieu
    {
        //khai bao cac thuoc tinh
        protected string? maTL;
        protected string? tenNXB;
        protected int soBanPH;
        //pt khoi tao mac dinh
        public TaiLieu() { }
        //pt khoi tao co tham so
        public TaiLieu(string maTL, string tenNXB, int soBanPH)
        {
            this.maTL = maTL;
            this.tenNXB = tenNXB;
            this.soBanPH = soBanPH;
        }
        //pt nhap thong tin tai lieu public
        public virtual void Nhap()
        {
            try
            {
                Console.WriteLine("+Ma tai lieu: ");
                string? v = Console.ReadLine();
                maTL = v;
                Console.WriteLine("+Ten nha xuat ban: ");
                tenNXB = Console.ReadLine();
                Console.WriteLine("+So ban phat hanh: ");
                soBanPH = int.Parse(Console.ReadLine() ?? "");

            }
            catch (Exception ex)
            {
                throw;
            }
        }
        // pt xuat thong tin tai lieu
        public virtual void Xuat()
        {
            Console.WriteLine($"+Ma tai lieu: {maTL}");
            Console.WriteLine($"+Ten nha xuat ban: {tenNXB}");
            Console.WriteLine($"+So ban phat hanh: {soBanPH}");
        }
    }
}
