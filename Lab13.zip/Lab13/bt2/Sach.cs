﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Lab13;
using static System.Net.Mime.MediaTypeNames;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace Lap13
{
    internal class Sach : TaiLieu
    {
        private string? tenTG;
        private int soTrang;

        public Sach() { }

        public Sach(string maTL, string tenNXB, int soBanPH, string tenTG, int soTrang)
            : base(maTL, tenNXB, soBanPH)
        {
            this.tenTG = tenTG;
            this.soTrang = soTrang;
        }

        public override void Nhap()
        {
            base.Nhap();

            Console.Write("+ Tên tác giả: ");
            tenTG = Console.ReadLine();

            Console.Write("+ Số trang: ");
            while (!int.TryParse(Console.ReadLine(), out soTrang) || soTrang < 1)
            {
                Console.Write("=> Nhập lại (số nguyên > 0): ");
            }
        }

        public override void Xuat()
        {
            base.Xuat();
            Console.WriteLine($"+ Tên tác giả: {tenTG}");
            Console.WriteLine($"+ Số trang: {soTrang}");
        }
    }
}