﻿using Lap13;
using System.Text;

internal class Program
{
    static void Main()
    {
        Console.OutputEncoding = Encoding.UTF8; // Cho phép hiển thị tiếng Việt đúng

        Console.WriteLine("=== NHẬP THÔNG TIN SÁCH ===");
        Sach sach = new Sach();
        sach.Nhap();

        Console.WriteLine("\n=== THÔNG TIN SÁCH VỪA NHẬP ===");
        sach.Xuat();

        Console.WriteLine("\nNhấn phím bất kỳ để kết thúc...");
        Console.ReadKey();
    }
}
