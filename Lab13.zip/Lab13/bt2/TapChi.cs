﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;


namespace Lap13
{
    internal class TaiLieu
    {
        protected string? maTL;
        protected string? tenNXB;
        protected int soBanPH;

        public TaiLieu() { }

        public TaiLieu(string maTL, string tenNXB, int soBanPH)
        {
            this.maTL = maTL;
            this.tenNXB = tenNXB;
            this.soBanPH = soBanPH;
        }

        public virtual void Nhap()
        {
            try
            {
                Console.Write("+ Mã tài liệu: ");
                maTL = Console.ReadLine();

                Console.Write("+ Tên nhà xuất bản: ");
                tenNXB = Console.ReadLine();

                Console.Write("+ Số bản phát hành: ");
                while (!int.TryParse(Console.ReadLine(), out soBanPH) || soBanPH < 0)
                {
                    Console.Write("=> Nhập lại (số nguyên >= 0): ");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Lỗi nhập dữ liệu: " + ex.Message);
            }
        }

        public virtual void Xuat()
        {
            Console.WriteLine($"+ Mã tài liệu: {maTL}");
            Console.WriteLine($"+ Tên nhà xuất bản: {tenNXB}");
            Console.WriteLine($"+ Số bản phát hành: {soBanPH}");
        }
    }
}

