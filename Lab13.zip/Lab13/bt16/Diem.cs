﻿using System;

namespace bt16
{
       public class Diem
    {
        public double X { get; set; }
        public double Y { get; set; }

        // Toán tử tạo lập mặc định
        public Diem()
        {
            X = 0;
            Y = 0;
        }

        // Toán tử tạo lập có tham số
        public Diem(double x, double y)
        {
            X = x;
            Y = y;
        }

        // Phương thức in điểm
        public void InDiem()
        {
            Console.Write($"({X}, {Y})");
        }

        // Tính khoảng cách giữa 2 điểm
        public static double KhoangCach(Diem a, Diem b)
        {
            return Math.Sqrt(Math.Pow(a.X - b.X, 2) + Math.Pow(a.Y - b.Y, 2));
        }
    }

}
