﻿using System;

namespace bt16
{
       public class TamGiac
    {
        public Diem D1 { get; set; }
        public Diem D2 { get; set; }
        public Diem D3 { get; set; }

        // Constructor mặc định
        public TamGiac()
        {
            D1 = new Diem();
            D2 = new Diem();
            D3 = new Diem();
        }

        // Constructor với 3 điểm
        public TamGiac(Diem d1, Diem d2, Diem d3)
        {
            D1 = d1;
            D2 = d2;
            D3 = d3;
        }

        // Tính độ dài các cạnh
        private double Canh1()
        {
            return Diem.KhoangCach(D1, D2);
        }
        private double Canh2()
        {
            return Diem.KhoangCach(D2, D3);
        }
        private double Canh3()
        {
            return Diem.KhoangCach(D3, D1);
        }

        // Tính chu vi
        public double TinhChuVi()
        {
            return Canh1() + Canh2() + Canh3();
        }

        // Tính diện tích theo công thức Heron
        public double TinhDienTich()
        {
            double a = Canh1();
            double b = Canh2();
            double c = Canh3();
            double p = TinhChuVi() / 2.0;
            double s = Math.Sqrt(p * (p - a) * (p - b) * (p - c));
            return s;
        }

        // In tam giác
        public void InTamGiac()
        {
            Console.Write("Tam giác có điểm: ");
            D1.InDiem();
            Console.Write(", ");
            D2.InDiem();
            Console.Write(", ");
            D3.InDiem();
            Console.WriteLine();
        }
    }

}
