﻿using System;
using System.Text;
using bt16;

class Program
{
    static void Main()
    {
        Console.OutputEncoding = Encoding.UTF8;

        Console.Write("Nhập số lượng tam giác: ");
        int n = int.Parse(Console.ReadLine());

        TamGiac[] dsTamGiac = new TamGiac[n];

        for (int i = 0; i < n; i++)
        {
            Console.WriteLine($"Nhập 3 điểm của tam giác thứ {i + 1}:");
            Diem d1 = NhapDiem("Điểm 1");
            Diem d2 = NhapDiem("Điểm 2");
            Diem d3 = NhapDiem("Điểm 3");

            dsTamGiac[i] = new TamGiac(d1, d2, d3);
        }

        double tongChuVi = 0;
        double tongDienTich = 0;

        Console.WriteLine("\nDanh sách tam giác vừa nhập:");
        for (int i = 0; i < n; i++)
        {
            dsTamGiac[i].InTamGiac();
            double cv = dsTamGiac[i].TinhChuVi();
            double dt = dsTamGiac[i].TinhDienTich();
            Console.WriteLine($"  Chu vi: {cv:F2}, Diện tích: {dt:F2}");

            tongChuVi += cv;
            tongDienTich += dt;
        }

        Console.WriteLine($"\nTổng chu vi các tam giác: {tongChuVi:F2}");
        Console.WriteLine($"Tổng diện tích các tam giác: {tongDienTich:F2}");

        Console.ReadKey();
    }

    static Diem NhapDiem(string tenDiem)
    {
        Console.WriteLine($"{tenDiem}:");
        Console.Write("  Nhập hoành độ x: ");
        double x = double.Parse(Console.ReadLine());
        Console.Write("  Nhập tung độ y: ");
        double y = double.Parse(Console.ReadLine());
        return new Diem(x, y);
    }
}
