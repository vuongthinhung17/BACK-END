﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bt21
{
       public class HocSinh
    {
        public string HoTen { get; set; }
        public string GioiTinh { get; set; } // "Nam" hoặc "Nu"
        public double Toan { get; set; }
        public double Ly { get; set; }
        public double Hoa { get; set; }

        public HocSinh() { }

        public HocSinh(string hoTen, string gioiTinh, double toan, double ly, double hoa)
        {
            HoTen = hoTen;
            GioiTinh = gioiTinh;
            Toan = toan;
            Ly = ly;
            Hoa = hoa;
        }

        public virtual void Nhap()
        {
            Console.Write("Họ tên: ");
            HoTen = Console.ReadLine();
            Console.Write("Giới tính (Nam/Nu): ");
            GioiTinh = Console.ReadLine();
            Console.Write("Điểm Toán: ");
            Toan = double.Parse(Console.ReadLine());
            Console.Write("Điểm Lý: ");
            Ly = double.Parse(Console.ReadLine());
            Console.Write("Điểm Hóa: ");
            Hoa = double.Parse(Console.ReadLine());
        }

        public virtual void Xuat()
        {
            Console.WriteLine($"Họ tên: {HoTen}, Giới tính: {GioiTinh}, Toán: {Toan}, Lý: {Ly}, Hóa: {Hoa}");
        }
    }

}
