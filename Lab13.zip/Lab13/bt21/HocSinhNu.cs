﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bt21
{
       public class HocSinhNu : HocSinh
    {
        public double NuCong { get; set; }

        public override void Nhap()
        {
            base.Nhap();
            Console.Write("Điểm Nữ công: ");
            NuCong = double.Parse(Console.ReadLine());
        }

        public override void Xuat()
        {
            base.Xuat();
            Console.WriteLine($"Nữ công: {NuCong}");
        }
    }

}
