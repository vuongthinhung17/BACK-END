﻿using System;
using System.Collections.Generic;
using bt21;

class Program
{
    static void Main()
    {
        List<HocSinh> danhSach = new List<HocSinh>();

        Console.OutputEncoding = System.Text.Encoding.UTF8;
        Console.InputEncoding = System.Text.Encoding.UTF8;

        Console.Write("Nhập số học sinh: ");
        int n = int.Parse(Console.ReadLine());

        for (int i = 0; i < n; i++)
        {
            Console.WriteLine($"\nHọc sinh thứ {i + 1}:");
            Console.Write("Giới tính (Nam/Nu): ");
            string gt = Console.ReadLine().Trim();

            HocSinh hs;
            if (gt.Equals("Nam", StringComparison.OrdinalIgnoreCase))
                hs = new HocSinhNam();
            else
                hs = new HocSinhNu();

            hs.Nhap();
            danhSach.Add(hs);
        }

        Console.WriteLine("\nHọc sinh nam có điểm kỹ thuật >= 8:");
        foreach (var hs in danhSach)
        {
            if (hs is HocSinhNam nam && nam.KyThuat >= 8)
                nam.Xuat();
        }

        Console.WriteLine("\nDanh sách học sinh (Nam trước, Nữ sau):");
        foreach (var hs in danhSach)
        {
            if (hs is HocSinhNam)
                hs.Xuat();
        }
        foreach (var hs in danhSach)
        {
            if (hs is HocSinhNu)
                hs.Xuat();
        }
    }
}
