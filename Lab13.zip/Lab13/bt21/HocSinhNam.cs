﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bt21
{
        public class HocSinhNam : HocSinh
    {
        public double KyThuat { get; set; }

        public override void Nhap()
        {
            base.Nhap();
            Console.Write("Điểm Kỹ thuật: ");
            KyThuat = double.Parse(Console.ReadLine());
        }

        public override void Xuat()
        {
            base.Xuat();
            Console.WriteLine($"Kỹ thuật: {KyThuat}");
        }
    }

}
