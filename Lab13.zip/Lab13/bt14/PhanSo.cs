﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bt14
{
   
        internal class PhanSo
        {
            public int TuSo { get; set; }
            public int MauSo { get; set; }

            // Hàm tạo không đối
            public PhanSo()
            {
                TuSo = 0;
                MauSo = 1;
            }

            // Hàm tạo có đối
            public PhanSo(int tu, int mau)
            {
                TuSo = tu;
                MauSo = mau != 0 ? mau : 1;
            }

            public void Nhap()
            {
                Console.Write("Nhập tử số: ");
                TuSo = int.Parse(Console.ReadLine());

                do
                {
                    Console.Write("Nhập mẫu số (khác 0): ");
                    MauSo = int.Parse(Console.ReadLine());
                } while (MauSo == 0);
            }

            public void Xuat()
            {
                Console.WriteLine($"{TuSo}/{MauSo}");
            }

            // Tìm UCLN
            private int UCLN(int a, int b)
            {
                a = Math.Abs(a); b = Math.Abs(b);
                while (b != 0)
                {
                    int r = a % b;
                    a = b;
                    b = r;
                }
                return a;
            }

            public void RutGon()
            {
                int ucln = UCLN(TuSo, MauSo);
                TuSo /= ucln;
                MauSo /= ucln;

                // Chuẩn hóa dấu âm về tử số
                if (MauSo < 0)
                {
                    TuSo *= -1;
                    MauSo *= -1;
                }
            }

            public PhanSo Cong(PhanSo b)
            {
                int tu = TuSo * b.MauSo + b.TuSo * MauSo;
                int mau = MauSo * b.MauSo;
                PhanSo kq = new PhanSo(tu, mau);
                kq.RutGon();
                return kq;
            }

            public PhanSo Tru(PhanSo b)
            {
                int tu = TuSo * b.MauSo - b.TuSo * MauSo;
                int mau = MauSo * b.MauSo;
                PhanSo kq = new PhanSo(tu, mau);
                kq.RutGon();
                return kq;
            }

            public PhanSo Chia(PhanSo b)
            {
                int tu = TuSo * b.MauSo;
                int mau = MauSo * b.TuSo;
                PhanSo kq = new PhanSo(tu, mau);
                kq.RutGon();
                return kq;
            }

            public PhanSo Nhan(PhanSo b)
            {
                int tu = TuSo * b.TuSo;
                int mau = MauSo * b.MauSo;
                PhanSo kq = new PhanSo(tu, mau);
                kq.RutGon();
                return kq;
            }
        }
    }


