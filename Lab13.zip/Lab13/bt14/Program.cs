﻿using System;
using bt14;

namespace Bai14
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = System.Text.Encoding.UTF8;

            Console.WriteLine("Nhập phân số A:");
            PhanSo A = new PhanSo();
            A.Nhap();

            Console.WriteLine("Nhập phân số B:");
            PhanSo B = new PhanSo();
            B.Nhap();

            while (true)
            {
                Console.WriteLine("\n--- MENU ---");
                Console.WriteLine("1. Hiển thị phân số A và B");
                Console.WriteLine("2. Rút gọn phân số A và B");
                Console.WriteLine("3. Cộng A + B");
                Console.WriteLine("4. Trừ A - B");
                Console.WriteLine("5. Nhân A * B");
                Console.WriteLine("6. Chia A / B");
                Console.WriteLine("0. Thoát");
                Console.Write("Chọn: ");
                int chon = int.Parse(Console.ReadLine());

                switch (chon)
                {
                    case 1:
                        Console.Write("Phân số A: "); A.Xuat();
                        Console.Write("Phân số B: "); B.Xuat();
                        break;
                    case 2:
                        A.RutGon(); B.RutGon();
                        Console.WriteLine("Sau rút gọn:");
                        Console.Write("A = "); A.Xuat();
                        Console.Write("B = "); B.Xuat();
                        break;
                    case 3:
                        Console.Write("A + B = ");
                        A.Cong(B).Xuat();
                        break;
                    case 4:
                        Console.Write("A - B = ");
                        A.Tru(B).Xuat();
                        break;
                    case 5:
                        Console.Write("A * B = ");
                        A.Nhan(B).Xuat();
                        break;
                    case 6:
                        if (B.TuSo == 0)
                        {
                            Console.WriteLine("Không thể chia cho phân số 0.");
                        }
                        else
                        {
                            Console.Write("A / B = ");
                            A.Chia(B).Xuat();
                        }
                        break;
                    case 0:
                        return;
                    default:
                        Console.WriteLine("Lựa chọn không hợp lệ!");
                        break;
                }
            }
        }
    }
}
