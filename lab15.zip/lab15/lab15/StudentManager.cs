﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab15
{
    public static class StudentManager
    {
        public static List<Student> students = new List<Student>();

        public static bool AddStudent(Student student)
        {
            try
            {
                bool isExist = students.Any(x => x.studentId == student.studentId);
                if (isExist)
                    throw new Exception("Sinh viên đã tồn tại!");
                students.Add(student);
                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return false;
            }
        }

        public static bool EditStudent(Student student)
        {
            foreach (var item in students)
            {
                if (item.studentId == student.studentId)
                {
                    item.studentName = student.studentName;
                    item.age = student.age;
                    item.address = student.address;
                    item.phone = student.phone;
                    return true;
                }
            }
            return false;
        }

        public static bool DeleteStudent(Student student)
        {
            try
            {
                students.Remove(student);
                return true;
            }
            catch
            {
                return false;
            }
        }

        public static void GetStudents()
        {
            Console.WriteLine("ID\tNAME\t\tAGE\tPHONE\t\tADDRESS");
            foreach (var item in students)
            {
                Console.WriteLine($"{item.studentId}\t{item.studentName}\t{item.age}\t{item.phone}\t{item.address}");
            }
        }
    }

}
