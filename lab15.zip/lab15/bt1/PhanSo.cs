﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bt1
{
        public class PhanSo
        {
            public int TuSo { get; set; }
            public int MauSo { get; set; }

            public PhanSo()
            {
                TuSo = 0;
                MauSo = 1;
            }

            public PhanSo(int tu, int mau)
            {
                TuSo = tu;
                MauSo = (mau == 0) ? 1 : mau;
            }

            public void Nhap()
            {
                Console.Write("- Nhập tử số: ");
                TuSo = int.Parse(Console.ReadLine());
                Console.Write("- Nhập mẫu số (khác 0): ");
                MauSo = int.Parse(Console.ReadLine());
                if (MauSo == 0)
                {
                    Console.WriteLine("Mẫu số không được bằng 0. Gán mẫu số = 1.");
                    MauSo = 1;
                }
            }

            public PhanSo Cong(PhanSo p)
            {
                int tu = this.TuSo * p.MauSo + p.TuSo * this.MauSo;
                int mau = this.MauSo * p.MauSo;
                return RutGon(new PhanSo(tu, mau));
            }

            public static PhanSo RutGon(PhanSo p)
            {
                int gcd = UCLN(Math.Abs(p.TuSo), Math.Abs(p.MauSo));
                p.TuSo /= gcd;
                p.MauSo /= gcd;
                return p;
            }

            private static int UCLN(int a, int b)
            {
                while (b != 0)
                {
                    int temp = a % b;
                    a = b;
                    b = temp;
                }
                return a;
            }

            public override string ToString()
            {
                return $"{TuSo}/{MauSo}";
            }
        }
    }


