﻿using System;
using System.Collections.Generic;
using bt1;

namespace FractionApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = System.Text.Encoding.UTF8;
            List<PhanSo> danhSachPhanSo = new List<PhanSo>();

            Console.Write("Nhập số lượng phân số: ");
            int n = int.Parse(Console.ReadLine());

            for (int i = 0; i < n; i++)
            {
                Console.WriteLine($"\nPhân số thứ {i + 1}:");
                PhanSo ps = new PhanSo();
                ps.Nhap();
                danhSachPhanSo.Add(ps);
            }

            // Tính tổng các phân số
            PhanSo tong = new PhanSo(0, 1);
            foreach (var ps in danhSachPhanSo)
            {
                tong = tong.Cong(ps);
            }

            Console.WriteLine($"\nTổng các phân số là: {tong}");
        }
    }
}
