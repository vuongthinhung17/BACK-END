﻿using System;
using System.Collections.Generic;
using bt2;

namespace HinhHoc
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = System.Text.Encoding.UTF8;

            List<Hinh> dsHinh = new List<Hinh>();

            dsHinh.Add(new HinhTron(3));
            dsHinh.Add(new HinhVuong(4));
            dsHinh.Add(new HinhChuNhat(5, 3));
            dsHinh.Add(new HinhTamGiac(3, 4, 5));

            double tongChuVi = 0, tongDienTich = 0;

            foreach (var h in dsHinh)
            {
                double cv = h.TinhChuVi();
                double dt = h.TinhDienTich();
                tongChuVi += cv;
                tongDienTich += dt;

                Console.WriteLine($"Chu vi: {cv:F2}, Diện tích: {dt:F2}");
            }

            Console.WriteLine($"\nTổng chu vi các hình: {tongChuVi:F2}");
            Console.WriteLine($"Tổng diện tích các hình: {tongDienTich:F2}");
        }
    }
}
