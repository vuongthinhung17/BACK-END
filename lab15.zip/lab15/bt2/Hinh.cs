﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bt2
{
    public abstract class Hinh
        {
            public abstract double TinhChuVi();
            public abstract double TinhDienTich();
        }
    }


