﻿using Microsoft.AspNetCore.Mvc;
using bt1.Models;
namespace bt1.Controllers
{
    public class ProductController : Controller
    {
            public IActionResult Details()
            {
                // Tạo đối tượng sản phẩm
                var product = new Product
                {
                    Id = 1,
                    Name = "Laptop Dell XPS 13",
                    Price = 29999.99m
                };
                return View(product);
            }
        }
    }


